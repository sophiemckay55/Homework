<?php

echo "You are not authorized to view this page<br>";
echo "<a href='login-form.php'>back to login</a>";

?>