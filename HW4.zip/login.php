<?php

$hn='localhost';
$db='movie';
$un='root';
$pw='root';



?>